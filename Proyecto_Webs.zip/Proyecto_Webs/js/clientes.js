const form = document.getElementById("formCliente");
const tabla = document.querySelector("#tablaClientes tbody");
let clientes = [];
let editando = -1;

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const nombre = document.getElementById("nombre").value;
  const correo = document.getElementById("correo").value;
  const telefono = document.getElementById("telefono").value;

  const cliente = { nombre, correo, telefono };

  if (editando >= 0) {
    clientes[editando] = cliente;
    editando = -1;
  } else {
    clientes.push(cliente);
  }

  form.reset();
  renderClientes();
});

function renderClientes() {
  tabla.innerHTML = "";
  clientes.forEach((cliente, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${cliente.nombre}</td>
      <td>${cliente.correo}</td>
      <td>${cliente.telefono}</td>
      <td>
        <button onclick="editarCliente(${index})">Editar</button>
        <button onclick="eliminarCliente(${index})">Eliminar</button>
      </td>
    `;
    tabla.appendChild(row);
  });
}

function editarCliente(index) {
  const cliente = clientes[index];
  document.getElementById("nombre").value = cliente.nombre;
  document.getElementById("correo").value = cliente.correo;
  document.getElementById("telefono").value = cliente.telefono;
  editando = index;
}

function eliminarCliente(index) {
  if (confirm("¿Estás seguro de eliminar este cliente?")) {
    clientes.splice(index, 1);
    renderClientes();
  }
}
