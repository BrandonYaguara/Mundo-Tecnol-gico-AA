function validarRecuperacion() {
  const correo = document.getElementById("correo").value;
  const errorMensaje = document.getElementById("errorMensaje");

  if (!correo.includes("@") || !correo.includes(".")) {
    errorMensaje.textContent = "Por favor, ingresa un correo válido.";
    return false;
  }

  errorMensaje.textContent = "";
  alert("Se han enviado las instrucciones a tu correo.");
  return true;
}
