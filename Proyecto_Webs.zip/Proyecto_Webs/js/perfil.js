function editarPerfil() {
  alert("Funcionalidad para editar perfil (próximamente).");
}

function cambiarPassword() {
  alert("Funcionalidad para cambiar contraseña (próximamente).");
}

