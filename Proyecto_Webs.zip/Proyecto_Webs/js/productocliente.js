let productosCliente = JSON.parse(localStorage.getItem("productosCliente")) || [];
let editandoProductoCliente = -1;

function mostrarProductosCliente() {
  const tbody = document.querySelector("#tablaProductoCliente tbody");
  tbody.innerHTML = "";
  productosCliente.forEach((p, i) => {
    const fila = document.createElement("tr");
    fila.innerHTML = `
      <td>${p.cliente}</td>
      <td>${p.marca}</td>
      <td>${p.modelo}</td>
      <td>${p.estado}</td>
      <td>
        <button onclick="editarProductoCliente(${i})">Editar</button>
        <button onclick="eliminarProductoCliente(${i})">Eliminar</button>
      </td>
    `;
    tbody.appendChild(fila);
  });
}

document.getElementById("formProductoCliente").addEventListener("submit", function(e) {
  e.preventDefault();
  
  const cliente = document.getElementById("clienteProducto").value.trim();
  const marca = document.getElementById("marcaProducto").value.trim();
  const modelo = document.getElementById("modeloProducto").value.trim();
  const estado = document.getElementById("estadoProducto").value;

  if (!cliente || !marca || !modelo) {
    alert("Por favor completa todos los campos");
    return;
  }

  if (editandoProductoCliente >= 0) {
    productosCliente[editandoProductoCliente] = { cliente, marca, modelo, estado };
    editandoProductoCliente = -1;
  } else {
    productosCliente.push({ cliente, marca, modelo, estado });
  }

  localStorage.setItem("productosCliente", JSON.stringify(productosCliente));
  mostrarProductosCliente();
  this.reset();
});

function editarProductoCliente(i) {
  const p = productosCliente[i];
  document.getElementById("clienteProducto").value = p.cliente;
  document.getElementById("marcaProducto").value = p.marca;
  document.getElementById("modeloProducto").value = p.modelo;
  document.getElementById("estadoProducto").value = p.estado;
  editandoProductoCliente = i;
}

function eliminarProductoCliente(i) {
  if (confirm("¿Seguro que quieres eliminar este producto?")) {
    productosCliente.splice(i, 1);
    localStorage.setItem("productosCliente", JSON.stringify(productosCliente));
    mostrarProductosCliente();
    if(editandoProductoCliente === i) {
      editandoProductoCliente = -1;
      document.getElementById("formProductoCliente").reset();
    }
  }
}

// Cargar la tabla al cargar la página
mostrarProductosCliente();
