
    function validarFormulario() {
      const contrasena = document.getElementById("contrasena").value;
      const confirmar = document.getElementById("confirmar").value;
      const errorMensaje = document.getElementById("errorMensaje");

      if (contrasena.length < 8) {
        errorMensaje.textContent = "La contraseña debe tener al menos 8 caracteres.";
        return false;
      }

      if (contrasena !== confirmar) {
        errorMensaje.textContent = "Las contraseñas no coinciden.";
        return false;
      }

      errorMensaje.textContent = "";
      return true;
    }