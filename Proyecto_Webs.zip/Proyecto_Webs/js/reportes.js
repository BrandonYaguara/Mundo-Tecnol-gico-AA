function generarReporte() {
  const tipo = document.getElementById("tipo").value;
  const contenido = document.getElementById("reporte-contenido");

  let html = "";

  switch (tipo) {
    case "ventas":
      html = `
        <h3>Reporte de Ventas</h3>
        <ul>
          <li>Venta #001 - $250</li>
          <li>Venta #002 - $320</li>
          <li>Venta #003 - $150</li>
        </ul>`;
      break;

    case "mantenimientos":
      html = `
        <h3>Reporte de Mantenimientos</h3>
        <ul>
          <li>Mantenimiento Laptop - $100</li>
          <li>Revisión de PC - $60</li>
        </ul>`;
      break;

    case "ingresos":
      html = `
        <h3>Reporte de Ingresos</h3>
        <p>Total mensual: $2,450</p>
        <p>Total anual: $28,300</p>`;
      break;

    default:
      html = "<p>Selecciona un tipo de reporte para ver la información.</p>";
  }

  contenido.innerHTML = html;
}


