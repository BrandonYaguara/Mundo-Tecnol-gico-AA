document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const mensajeDiv = document.getElementById('mensaje');

  form.addEventListener('submit', function(event) {
    event.preventDefault(); // Detiene el envío automático

    const email = form.email.value.trim();
    const password = form.password.value.trim();

    mensajeDiv.style.color = 'red'; // por defecto, error en rojo
    mensajeDiv.textContent = '';    // limpiar mensaje previo

    if (email === '' || password === '') {
      mensajeDiv.textContent = 'Por favor, completa todos los campos.';
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      mensajeDiv.textContent = 'Por favor, ingresa un correo electrónico válido.';
      return;
    }

    if (password.length < 8) {
      mensajeDiv.textContent = 'La contraseña debe tener al menos 8 caracteres.';
      return;
    }

    // Si todo está bien, mensaje éxito
    mensajeDiv.style.color = 'green';
    mensajeDiv.textContent = 'Inicio de sesión exitoso. Redirigiendo...';

    setTimeout(() => {
      window.location.href = 'dashboard.html';
    }, 1500);
  });
});
